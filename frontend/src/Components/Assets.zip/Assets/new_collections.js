import nc1_img from './popular-brownies.jpg'
import nc2_img from './popular-brownies.jpg'
import nc3_img from './popular-brownies.jpg'
import nc4_img from './popular-brownies.jpg'
import nc5_img from './popular-brownies.jpg'
import nc6_img from './popular-brownies.jpg'
import nc7_img from './popular-brownies.jpg'
import nc8_img from './popular-brownies.jpg'

let new_collections = [
  {
    id: 1,
    name: "Brownies 1",
    image: nc1_img,
    new_price: 50.00,
    old_price: 80.50,
  },
  {
    id: 2,
    name: "Brownies 2",
    image: nc2_img,
    new_price: 50.00,
    old_price: 80.50,
  },
  {
    id: 3,
    name: "Brownies 3",
    image: nc3_img,
    new_price: 50.00,
    old_price: 80.50,
  },
  {
    id: 4,
    name: "Brownies 4",
    image: nc4_img,
    new_price: 50.00,
    old_price: 80.50,
  },
  {
    id: 5,
    name: "Brownies 4",
    image: nc5_img,
    new_price: 50.00,
    old_price: 80.50,
  },
  {
    id: 6,
    name: "Brownies 4",
    image: nc6_img,
    new_price: 50.00,
    old_price: 80.50,
  },
  {
    id: 7,
    name: "Brownies 4",
    image: nc7_img,
    new_price: 50.00,
    old_price: 80.50,
  },
  {
    id: 8,
    name: "Brownies 4",
    image: nc8_img,
    new_price: 50.00,
    old_price: 80.50,
  },
]

export default new_collections