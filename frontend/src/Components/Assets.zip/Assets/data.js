import p1_img from './popular-brownies.jpg'
import p2_img from './popular-brownies.jpg'
import p3_img from './popular-brownies.jpg'
import p4_img from './popular-brownies.jpg'

let data_product = [
  {
    id: 1,
    name: "Brownies Ori",
    image: p1_img,
    new_price: 15000,
    old_price: 80.50,
  },
  {
    id: 2,
    name: "Brownies Keju",
    image: p2_img,
    new_price: 15000,
    old_price: 80.50,
  },
  {
    id: 3,
    name: "Brownies Oreo",
    image: p3_img,
    new_price: 16000,
    old_price: 80.50,
  },
  {
    id: 4,
    name: "Brownies Mix",
    image: p4_img,
    new_price: 16000,
    old_price: 80.50,
  },
]

export default data_product